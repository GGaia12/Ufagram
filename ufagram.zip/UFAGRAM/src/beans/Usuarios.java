package beans;

/**
 *
 * @author bielg
 */
public class Usuarios {
    private int id;
    private String login;
    private String email;
    private String numero;
    private String datansc;
    private String senha;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getNumero() {
        return numero;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }

    public String getDatansc() {
        return datansc;
    }

    public void setDatansc(String datansc) {
        this.datansc = datansc;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }
    
    
}
