package ufagram;

import conexao.Conexao;

/**
 *
 * @author bielg
 */
public class UFAGRAM {

    public static void main(String[] args) {
        Conexao c = new Conexao();
        c.getConexao();
    }
    
}
