package conexao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

/**
 *
 * @author bielg
 */
public class Conexao {
     public Connection getConexao(){
        try{
            // Tenta conexão
            Connection conn = DriverManager.getConnection(
            "jdbc:mysql://localhost:3306/ufagrambd?serverTimezone=UTC", // Linha de conexão
                "root", // usuario do mysql
                "" //senha do mysql
            );
            Statement stmt = conn.createStatement();
            return conn;
        } catch (Exception e) {
            //Caso aconteceça algum erro
            System.out.println("Erro ao conectar" + e.getMessage());
            return null;
        }
    } 
    }
    
    



 






   

 