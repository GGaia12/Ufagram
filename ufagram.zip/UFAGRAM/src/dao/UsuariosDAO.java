/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import beans.Usuarios;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import conexao.Conexao;

/**
 *
 * @author bielg
 */
public class UsuariosDAO {
    private Conexao conexao;
    private Connection conn;
    
    // Construtor da classe
    
public UsuariosDAO() {
    this.conexao = new Conexao();
    this.conn = this.conexao.getConexao();
}
public void inserir(Usuarios usuarios){
    String sql = "INSERT INTO usuarios(login, email, numero, datansc, senha) VALUES "
            + ("(?,?,?,?,?)");
    try{
    PreparedStatement stmt = this.conn.prepareStatement(sql);
    stmt.setString(1, usuarios.getLogin());
    stmt.setString(2, usuarios.getEmail());
    stmt.setString(3, usuarios.getNumero());
    stmt.setString(4, usuarios.getDatansc());
    stmt.setString(5, usuarios.getSenha());
    stmt.execute();
    }
    catch(Exception e){
        System.out.println("Erro ao inserir Usuario" + e.getMessage());
    }
}
public Usuarios buscarPorLoginESenha(Usuarios usuario) {
    String sql = "SELECT * FROM usuarios WHERE login = ? AND senha = ?";
    try {
        PreparedStatement stmt = this.conn.prepareStatement(sql);
        stmt.setString(1, usuario.getLogin());
        stmt.setString(2, usuario.getSenha());
        ResultSet rs = stmt.executeQuery();
        if (rs.next()) {
            Usuarios usuarioExistente = new Usuarios();
            usuarioExistente.setId(rs.getInt("id"));
            usuarioExistente.setLogin(rs.getString("login"));
            usuarioExistente.setSenha(rs.getString("senha"));
            return usuarioExistente;
        }
    } catch (Exception e) {
        System.out.println("Erro ao buscar usuário: " + e.getMessage());
    }
    return null;
}
    
}
